This is a sample blog using NodeJS, ExpressJS, Jade, mongodb and mongoose. The base of blog was built by following the online tutorial from MongoDB University.  

The record of the commond lines in Terminal while the blog app was created.
	npm init
	npm install mongoose --save
	touch app.js
	npm install express --save
	npm install jade --save
	mkdir routes
	touch index.js 		// this creates index.js file in ./routes directory    
	mkdir views
	touch home.jade 	// it creates home.jade file in the ./view directory
	touch layout.jade 	// it creates layout.jade file in the ./view directory