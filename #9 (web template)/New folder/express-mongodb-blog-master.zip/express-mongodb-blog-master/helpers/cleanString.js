module.exports = function (param) {
	return param.trim();
};